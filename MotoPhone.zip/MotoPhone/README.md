# Moto Phone

A Samsung One UI–style phone app (dialer, call screen, recents, contacts) for the **moto g96 5G**.
Kotlin + Jetpack Compose. Min Android 10 (API 29), target Android 15 (API 35).

## Build & install
1. Install **Android Studio** (Ladybug or newer). Open this `MotoPhone` folder and let Gradle sync.
2. On the phone: Settings → About phone → tap *Build number* 7 times → Developer options → enable **USB debugging**.
3. Connect via USB, pick the moto g96 in Android Studio, press **Run ▶**.
   (Or `Build > Build APK(s)` and copy `app/build/outputs/apk/debug/app-debug.apk` to the phone.)
4. Open **Moto Phone** → tap **Set** on the banner → choose *Moto Phone* as the default phone app.
   Without this step the app can dial, but incoming/active call screens, blocking and decline messages won't work.

## Features
- **Keypad**: Samsung-style pad, DTMF tones, smart dial (T9 name + number search), paste, last-number redial,
  long-press `0` = `+`, long-press `1` = voicemail, long-press `2–9` = speed dial, add-to-contacts shortcut.
- **Dual SIM**: choose SIM 1 / SIM 2 when calling (can be turned off in Settings).
- **Recents**: grouped log (e.g. "Alex (3)"), filters (All / Missed / Received / Dialled), search,
  tap to expand → Call / Message / Details, long-press multi-select delete, block number.
- **Contacts**: search, favourites row, A–Z sticky headers + quick-jump bar, contact sheet
  (call, message, edit, favourite).
- **Call screen**: incoming (Accept / Decline / Send message), outgoing, active with
  Add call, Hold, Keypad (DTMF), Bluetooth, Speaker, Mute; second-call banner with Swap / Merge;
  proximity screen-off; shows over lock screen; notification with Answer / Decline / Hang up.
- **Settings**: default-app status, blocked numbers, speed dial, quick decline messages, SIM options,
  voicemail, ringtone shortcut, keypad tones/vibration, proximity toggle.

## Notes
- Ringtone and vibration are played by Android's telecom system; change them in system Sound settings
  (Settings → Ringtone and vibration opens that page).
- "Send message" on decline uses your default SMS app (Google Messages on the g96).
- Not included (not possible for a normal app): call recording, Samsung-only features like Bixby/RTT/video-call effects.
