package com.motophone.telecom

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

/** Placing calls, including dual-SIM selection (moto g96 5G is dual SIM). */
object CallPlacer {

    private fun tm(ctx: Context) = ctx.getSystemService(TelecomManager::class.java)

    fun accounts(ctx: Context): List<PhoneAccountHandle> =
        runCatching { tm(ctx).callCapablePhoneAccounts }.getOrDefault(emptyList())

    fun label(ctx: Context, h: PhoneAccountHandle): String =
        runCatching { tm(ctx).getPhoneAccount(h)?.label?.toString() }.getOrNull() ?: "SIM"

    fun call(ctx: Context, number: String, handle: PhoneAccountHandle? = null) {
        val extras = Bundle()
        if (handle != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
        tm(ctx).placeCall(Uri.fromParts(PhoneAccount.SCHEME_TEL, number, null), extras)
    }

    fun callVoicemail(ctx: Context) {
        tm(ctx).placeCall(Uri.fromParts(PhoneAccount.SCHEME_VOICEMAIL, "", null), Bundle())
    }
}
