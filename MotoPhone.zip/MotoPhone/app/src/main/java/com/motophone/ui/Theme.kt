package com.motophone.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MotoBlue = Color(0xFF3E91FF)
val CallGreen = Color(0xFF34C759)
val EndRed = Color(0xFFFF3B30)

/** One UI inspired palette: soft grey canvas in light mode, true black in dark mode. */
@Composable
fun MotoTheme(forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = forceDark || isSystemInDarkTheme()
    val colors = if (dark) {
        darkColorScheme(
            primary = MotoBlue,
            onPrimary = Color.White,
            background = Color(0xFF000000),
            onBackground = Color.White,
            surface = Color(0xFF000000),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF252525),
            onSurfaceVariant = Color(0xFFB5B5B5),
            secondaryContainer = Color(0xFF1F3556),
            onSecondaryContainer = MotoBlue,
            surfaceContainerLow = Color(0xFF1C1C1E),
            surfaceContainerHigh = Color(0xFF2A2A2C),
            outlineVariant = Color(0xFF333333),
        )
    } else {
        lightColorScheme(
            primary = MotoBlue,
            onPrimary = Color.White,
            background = Color(0xFFF6F6F6),
            onBackground = Color(0xFF111111),
            surface = Color(0xFFF6F6F6),
            onSurface = Color(0xFF111111),
            surfaceVariant = Color.White,
            onSurfaceVariant = Color(0xFF6B6B6B),
            secondaryContainer = Color(0xFFDCE9FF),
            onSecondaryContainer = MotoBlue,
            surfaceContainerLow = Color.White,
            surfaceContainerHigh = Color.White,
            outlineVariant = Color(0xFFE0E0E0),
        )
    }
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
