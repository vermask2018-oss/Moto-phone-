package com.motophone.ui

import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motophone.data.ContactItem
import kotlinx.coroutines.launch

private fun letterOf(name: String): Char {
    val c = name.firstOrNull()?.uppercaseChar() ?: '#'
    return if (c.isLetter()) c else '#'
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ContactsScreen(
    contacts: List<ContactItem>,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onCall: (String) -> Unit,
    onChanged: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ContactItem?>(null) }
    var menu by remember { mutableStateOf(false) }

    val filtered = remember(contacts, query) {
        val q = query.trim()
        val qd = q.filter { it.isDigit() }
        if (q.isEmpty()) contacts
        else contacts.filter { c ->
            c.name.contains(q, true) || (qd.isNotEmpty() && c.numbers.any { n -> n.filter { it.isDigit() }.contains(qd) })
        }
    }
    val favs = remember(filtered, query) { if (query.isBlank()) filtered.filter { it.starred } else emptyList() }
    val groups = remember(filtered) {
        filtered.groupBy { letterOf(it.name) }.toSortedMap(compareBy<Char> { if (it == '#') '￿' else it })
    }
    val indexOf = remember(groups, favs) {
        val m = HashMap<Char, Int>()
        var pos = if (favs.isNotEmpty()) 1 else 0
        groups.forEach { (l, list) -> m[l] = pos; pos += 1 + list.size }
        m
    }
    val listState = rememberLazyListState()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Contacts", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                runCatching {
                    ctx.startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI))
                }
            }) { Icon(Icons.Filled.Add, "New contact") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onOpenSettings() })
                }
            }
        }

        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search contacts") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )

        if (!hasPermission) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Allow contacts access to see your contacts.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRequestPermission) { Text("Allow") }
            }
        } else if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No contacts", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Box(Modifier.fillMaxSize()) {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(end = 22.dp)) {
                    if (favs.isNotEmpty()) {
                        item {
                            Column(Modifier.padding(bottom = 8.dp)) {
                                Text(
                                    "Favourites", fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                                )
                                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp)) {
                                    items(favs, key = { it.id }) { c ->
                                        Column(
                                            Modifier
                                                .width(76.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                                .clickable { selected = c }
                                                .padding(4.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            ContactAvatar(c.name, c.photoUri, 56.dp)
                                            Text(
                                                c.name, fontSize = 12.sp, maxLines = 1,
                                                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    groups.forEach { (letter, list) ->
                        stickyHeader {
                            Text(
                                letter.toString(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.background)
                                    .padding(horizontal = 20.dp, vertical = 6.dp)
                            )
                        }
                        items(list, key = { it.id }) { c ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { selected = c }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ContactAvatar(c.name, c.photoUri, 44.dp)
                                Spacer(Modifier.width(14.dp))
                                Text(c.name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }

                // Alphabet quick-jump bar
                Column(Modifier.align(Alignment.CenterEnd).padding(end = 2.dp)) {
                    groups.keys.forEach { l ->
                        Text(
                            l.toString(), fontSize = 10.sp, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clickable { scope.launch { listState.animateScrollToItem(indexOf[l] ?: 0) } }
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }

    selected?.let { c ->
        ModalBottomSheet(onDismissRequest = { selected = null }) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ContactAvatar(c.name, c.photoUri, 88.dp)
                Spacer(Modifier.height(12.dp))
                Text(c.name, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                c.numbers.forEach { n ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatNumber(n), fontSize = 17.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { selected = null; onCall(n) }) {
                            Icon(Icons.Filled.Call, "Call", tint = CallGreen)
                        }
                        IconButton(onClick = {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n"))) }
                        }) { Icon(Icons.Filled.Sms, "Message", tint = MotoBlue) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    TextButton(onClick = {
                        runCatching {
                            val v = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (c.starred) 0 else 1) }
                            ctx.contentResolver.update(
                                ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id), v, null, null
                            )
                        }
                        selected = null
                        onChanged()
                    }) {
                        Icon(if (c.starred) Icons.Filled.Star else Icons.Filled.StarBorder, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (c.starred) "Unfavourite" else "Favourite")
                    }
                    TextButton(onClick = {
                        val uri = ContactsContract.Contacts.getLookupUri(c.id, c.lookupKey)
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE)
                            )
                        }
                        selected = null
                    }) {
                        Icon(Icons.Filled.Edit, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Edit")
                    }
                }
            }
        }
    }
}
