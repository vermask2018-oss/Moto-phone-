package com.motophone.data

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Perms {
    val core = arrayOf(
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_PHONE_STATE,
    )

    val all: Array<String> = buildList {
        addAll(core)
        add(Manifest.permission.WRITE_CONTACTS)
        add(Manifest.permission.WRITE_CALL_LOG)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    fun has(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    fun hasCore(ctx: Context) = core.all { has(ctx, it) }
    fun hasAll(ctx: Context) = all.all { has(ctx, it) }
}

object DefaultDialer {
    fun isHeld(ctx: Context): Boolean = runCatching {
        ctx.getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_DIALER)
    }.getOrDefault(false)

    fun requestIntent(ctx: Context): Intent =
        ctx.getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_DIALER)
}
