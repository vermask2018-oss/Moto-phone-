package com.motophone.data

data class CallLogEntry(
    val ids: List<Long>,
    val number: String,
    val name: String?,
    val type: Int,
    val date: Long,
    val duration: Long,
    val count: Int,
    val photoUri: String?,
    val geo: String?,
) {
    val id: Long get() = ids.first()
}

data class ContactItem(
    val id: Long,
    val name: String,
    val numbers: List<String>,
    val photoUri: String?,
    val starred: Boolean,
    val lookupKey: String?,
)
