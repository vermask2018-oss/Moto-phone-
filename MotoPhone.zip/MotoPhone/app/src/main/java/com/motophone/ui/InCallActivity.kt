package com.motophone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.motophone.MainActivity
import com.motophone.data.Prefs
import com.motophone.telecom.CallManager
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class InCallActivity : ComponentActivity() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()
        handleIntent(intent)

        // Turn the screen off near the ear (proximity), unless speaker / Bluetooth is on.
        lifecycleScope.launch {
            combine(CallManager.state, CallManager.audio) { calls, audio -> calls to audio }
                .collect { (calls, audio) ->
                    val inCall = calls.any {
                        it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING ||
                            it.state == Call.STATE_CONNECTING
                    }
                    val route = audio?.route
                    val loud = route == CallAudioState.ROUTE_SPEAKER || route == CallAudioState.ROUTE_BLUETOOTH
                    setProximity(inCall && !loud)
                }
        }

        setContent {
            MotoTheme(forceDark = true) {
                InCallScreen(
                    onAddCall = {
                        startActivity(
                            Intent(this, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                        )
                    },
                    onFinish = { finishAndRemoveTask() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_ANSWER, false) == true) {
            CallManager.answerRinging()
            i.removeExtra(EXTRA_ANSWER)
        }
    }

    private fun setProximity(enable: Boolean) {
        val pm = getSystemService(PowerManager::class.java)
        if (enable && Prefs.bool(this, Prefs.PROXIMITY) &&
            pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)
        ) {
            val lock = wakeLock ?: pm.newWakeLock(
                PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "motophone:proximity"
            ).also { wakeLock = it }
            if (!lock.isHeld) lock.acquire(4 * 60 * 60 * 1000L)
        } else {
            wakeLock?.let { if (it.isHeld) it.release() }
        }
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ANSWER = "answer_call"

        fun intent(ctx: Context): Intent =
            Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
