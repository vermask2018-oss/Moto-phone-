package com.motophone.telecom

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telecom.Call
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import com.motophone.R
import com.motophone.ui.InCallActivity
import com.motophone.ui.formatNumber

object CallNotifications {
    private const val ID = 1001
    private const val CH_INCOMING = "moto_incoming_calls"
    private const val CH_ONGOING = "moto_ongoing_calls"
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH_INCOMING) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_INCOMING, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                    // Ringtone / vibration are played by the system telecom stack.
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
        }
        if (nm.getNotificationChannel(CH_ONGOING) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_ONGOING, "Ongoing calls", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                }
            )
        }
    }

    fun update(ctx: Context, calls: List<CallInfo>) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val primary = CallManager.primary(calls)
        if (primary == null || primary.state == Call.STATE_DISCONNECTED) {
            nm.cancel(ID)
            return
        }
        ensureChannels(ctx)

        val title = primary.name ?: formatNumber(primary.number).ifBlank { "Unknown" }
        val person = Person.Builder().setName(title).setImportant(true).build()
        val contentPI = PendingIntent.getActivity(ctx, 0, InCallActivity.intent(ctx), FLAGS)
        val ringing = primary.state == Call.STATE_RINGING

        val builder = NotificationCompat.Builder(ctx, if (ringing) CH_INCOMING else CH_ONGOING)
            .setSmallIcon(R.drawable.ic_stat_call)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentPI)

        if (ringing) {
            val answerPI = PendingIntent.getActivity(
                ctx, 1, InCallActivity.intent(ctx).putExtra(InCallActivity.EXTRA_ANSWER, true), FLAGS
            )
            val declinePI = PendingIntent.getBroadcast(
                ctx, 2,
                Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE),
                FLAGS
            )
            builder
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setFullScreenIntent(contentPI, true)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declinePI, answerPI))
        } else {
            val hangupPI = PendingIntent.getBroadcast(
                ctx, 3,
                Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_HANGUP),
                FLAGS
            )
            builder
                .setContentTitle(title)
                .setContentText(
                    when (primary.state) {
                        Call.STATE_HOLDING -> "On hold"
                        Call.STATE_ACTIVE -> "Ongoing call"
                        else -> "Calling…"
                    }
                )
                .setUsesChronometer(primary.state == Call.STATE_ACTIVE && primary.connectTime > 0)
                .setWhen(if (primary.connectTime > 0) primary.connectTime else System.currentTimeMillis())
                .addAction(
                    NotificationCompat.Action.Builder(R.drawable.ic_stat_call, "Hang up", hangupPI).build()
                )
        }
        nm.notify(ID, builder.build())
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID)
    }
}
